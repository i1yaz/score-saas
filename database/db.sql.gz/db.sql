-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 27, 2023 at 08:32 PM
-- Server version: 8.0.33
-- PHP Version: 8.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scoreitnow_saas`
--

-- --------------------------------------------------------

--
-- Table structure for table `api_calls_count`
--

CREATE TABLE `api_calls_count` (
  `id` bigint UNSIGNED NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `first_name`, `last_name`, `email`, `address`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'Laurie', 'Fadel', 'ykertzmann@example.org', '87461 Adams Burgs\nEast Jaida, MN 61258', 1, 'web', 1, '2023-10-26 22:41:06', '2023-10-26 22:41:06'),
(2, 'Madalyn', 'Ernser', 'mohammad42@example.com', '39469 Jaquan Port Apt. 424\nEast Leoneshire, ID 56794-2115', 1, 'web', 1, '2023-10-26 22:41:09', '2023-10-26 22:41:09'),
(3, 'Angelita', 'Balistreri', 'jfeil@example.com', '13130 Kattie Valleys Apt. 869\nNorth Jakob, KS 07954-9539', 1, 'web', 1, '2023-10-26 22:41:10', '2023-10-26 22:41:10'),
(4, 'Dorris', 'Dicki', 'pgerlach@example.net', '14791 Maiya Springs Apt. 338\nEast Jaquantown, NV 49939-9223', 1, 'web', 1, '2023-10-26 22:41:10', '2023-10-26 22:41:10'),
(5, 'Jazmyne', 'Mohr', 'kurtis.sawayn@example.org', '35465 Llewellyn Mission\nTaureanville, LA 37018-6730', 1, 'web', 1, '2023-10-26 22:41:11', '2023-10-26 22:41:11'),
(6, 'Ava', 'Bruen', 'clemens.mitchell@example.org', '404 Legros Dale\nNorth Salvadorside, MN 36383', 1, 'web', 1, '2023-10-26 22:41:11', '2023-10-26 22:41:11'),
(7, 'Claud', 'Denesik', 'jamison.nitzsche@example.net', '687 Shanahan Course Apt. 201\nHilbertport, CO 04580-2054', 1, 'web', 1, '2023-10-26 22:41:12', '2023-10-26 22:41:12'),
(8, 'Jeff', 'Harvey', 'madisen.bashirian@example.org', '8173 Ritchie Plaza Apt. 952\nWest Cameronmouth, HI 73710-6706', 1, 'web', 1, '2023-10-26 22:41:12', '2023-10-26 22:41:12'),
(9, 'Montana', 'Kuvalis', 'hdonnelly@example.org', '185 Bogan Burgs\nChristinashire, WA 31639', 1, 'web', 1, '2023-10-26 22:41:12', '2023-10-26 22:41:12'),
(10, 'Verner', 'Gleichner', 'hayes.mariana@example.net', '775 Mac Square\nSydneymouth, HI 42430', 1, 'web', 1, '2023-10-26 22:41:12', '2023-10-26 22:41:12'),
(11, 'Nayeli', 'Considine', 'mosciski.johathan@example.com', '3179 Alisa Springs Apt. 222\nLabadieburgh, DE 96230-3054', 1, 'web', 1, '2023-10-26 22:41:12', '2023-10-26 22:41:12'),
(12, 'Grady', 'Dietrich', 'elisha32@example.org', '134 Hazle River\nNelleview, OR 07279', 1, 'web', 1, '2023-10-26 22:41:13', '2023-10-26 22:41:13'),
(13, 'Natasha', 'Durgan', 'rhett.okuneva@example.org', '324 Miracle Crossing Suite 002\nHarryfurt, FL 29343', 1, 'web', 1, '2023-10-26 22:41:13', '2023-10-26 22:41:13'),
(14, 'Kelvin', 'Rosenbaum', 'hilton.lehner@example.com', '62805 Marvin Cliff Suite 588\nZachariahville, AZ 43392-9420', 1, 'web', 1, '2023-10-26 22:41:13', '2023-10-26 22:41:13'),
(15, 'Colin', 'Mayer', 'dorothea26@example.org', '39036 Jenkins Parkways Suite 114\nSouth Neoma, MS 15336-6142', 1, 'web', 1, '2023-10-26 22:41:13', '2023-10-26 22:41:13'),
(16, 'Vena', 'Konopelski', 'hconroy@example.net', '20886 Connelly Park Suite 283\nNew Miltonberg, MN 42952-5455', 1, 'web', 1, '2023-10-26 22:41:13', '2023-10-26 22:41:13'),
(17, 'Daphnee', 'Skiles', 'vpurdy@example.net', '729 Earnestine Ranch\nHansenville, MA 51377-8064', 1, 'web', 1, '2023-10-26 22:41:14', '2023-10-26 22:41:14');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` bigint UNSIGNED NOT NULL,
  `invoice_package_type_id` bigint UNSIGNED NOT NULL COMMENT 'This is the invoice package type it looks like the type of package like Tutoring Package or Monthly Invoice etc',
  `due_date` timestamp NULL DEFAULT NULL,
  `fully_paid_at` timestamp NULL DEFAULT NULL,
  `general_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `detailed_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `email_to_parent` tinyint(1) NOT NULL DEFAULT '0',
  `email_to_student` tinyint(1) NOT NULL DEFAULT '0',
  `amount_paid` decimal(8,2) NOT NULL DEFAULT '0.00',
  `paid_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `paid_by_modal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_by_id` bigint DEFAULT NULL,
  `invoiceable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'This is the type of package like Tutoring Package or Monthly Invoice etc',
  `invoiceable_id` bigint NOT NULL COMMENT 'This is the primary key of above type of package',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `invoice_package_type_id`, `due_date`, `fully_paid_at`, `general_description`, `detailed_description`, `email_to_parent`, `email_to_student`, `amount_paid`, `paid_status`, `paid_by_modal`, `paid_by_id`, `invoiceable_type`, `invoiceable_id`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1000, 1, '2023-10-04 19:00:00', NULL, 'Soluta nihil Nam fug', 'Molestias fuga Qui', 1, 0, '0.00', '1', NULL, NULL, 'App\\Models\\StudentTutoringPackage', 3000, 1, 'web', 1, '2023-10-03 17:37:43', '2023-10-03 17:37:43'),
(1001, 1, '2023-10-05 19:00:00', NULL, 'Odio aut neque cupid', 'Facere est voluptas', 1, 0, '0.00', '1', NULL, NULL, 'App\\Models\\StudentTutoringPackage', 3001, 1, 'web', 1, '2023-10-04 02:36:16', '2023-10-04 02:36:16'),
(1002, 1, '2023-10-11 19:00:00', NULL, 'Cupiditate optio si', 'Laboriosam et conse', 1, 0, '0.00', '1', NULL, NULL, 'App\\Models\\StudentTutoringPackage', 3004, 1, 'web', 1, '2023-10-12 01:13:19', '2023-10-12 01:13:19'),
(1003, 2, '2023-10-20 19:00:00', NULL, 'Invoice for the previous month\'s hourly tutoring', NULL, 0, 0, '0.00', '0', NULL, NULL, 'App\\Models\\MonthlyInvoicePackage', 4001, 1, 'web', 1, '2023-10-13 23:54:55', '2023-10-13 23:54:55'),
(1004, 2, '2023-10-20 19:00:00', NULL, 'Invoice for the previous month\'s hourly tutoring', NULL, 0, 0, '0.00', '0', NULL, NULL, 'App\\Models\\MonthlyInvoicePackage', 4002, 1, 'web', 1, '2023-10-13 23:58:44', '2023-10-13 23:58:44'),
(1005, 2, NULL, NULL, 'Nostrum asperiores n', 'Non in amet consequ', 1, 0, '0.00', '0', NULL, NULL, 'App\\Models\\MonthlyInvoicePackage', 4003, 1, 'web', 1, '2023-10-14 09:31:21', '2023-10-14 09:31:21'),
(1006, 2, NULL, NULL, 'Dolore nostrum sint', 'Sed eiusmod natus ve', 1, 0, '0.00', '0', NULL, NULL, 'App\\Models\\MonthlyInvoicePackage', 4004, 1, 'web', 1, '2023-10-14 09:36:34', '2023-10-14 09:36:34'),
(1007, 2, NULL, NULL, 'Aut aute voluptatem', 'Duis eu animi ipsa', 1, 0, '0.00', '0', NULL, NULL, 'App\\Models\\MonthlyInvoicePackage', 4005, 1, 'web', 1, '2023-10-14 09:43:13', '2023-10-14 09:43:13'),
(1008, 2, NULL, NULL, 'Libero error suscipi', 'Quis et impedit ess', 0, 0, '0.00', '0', NULL, NULL, 'App\\Models\\MonthlyInvoicePackage', 4006, 1, 'web', 1, '2023-10-15 13:01:27', '2023-10-15 13:01:27'),
(1009, 2, NULL, '2023-10-15 13:15:27', 'Quo consectetur deb', 'Nihil eligendi et sa', 1, 0, '0.00', '3', NULL, NULL, 'App\\Models\\MonthlyInvoicePackage', 4007, 1, 'web', 1, '2023-10-15 13:15:27', '2023-10-15 13:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_package_types`
--

CREATE TABLE `invoice_package_types` (
  `id` bigint UNSIGNED NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invoice_package_types`
--

INSERT INTO `invoice_package_types` (`id`, `name`, `created_at`, `updated_at`, `status`, `auth_guard`, `added_by`) VALUES
(1, 'Tutoring Package', '2023-09-23 21:26:03', '2023-09-23 21:26:03', 1, '', 0),
(2, 'Monthly Invoice Tutoring', '2023-09-23 21:32:01', '2023-09-23 21:32:01', 1, '', 0),
(3, 'Mock Test', '2023-09-23 21:32:07', '2023-09-23 21:32:07', 1, '', 0),
(4, 'At Home Sessions', '2023-09-23 21:32:12', '2023-09-23 21:32:12', 1, '', 0),
(5, 'Non Package Invoice', '2023-09-23 21:32:17', '2023-10-06 01:03:14', 1, '', 0),
(6, 'Other', '2023-09-23 21:32:17', '2023-10-06 01:03:14', 1, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `line_items`
--

CREATE TABLE `line_items` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `line_items`
--

INSERT INTO `line_items` (`id`, `name`, `price`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'Line 1', '14.5', 1, 'web', 1, '2023-10-26 22:33:39', '2023-10-26 22:33:39'),
(2, 'new item', '10', 1, 'web', 1, '2023-10-26 22:34:12', '2023-10-26 22:34:12');

-- --------------------------------------------------------

--
-- Table structure for table `list_data`
--

CREATE TABLE `list_data` (
  `id` bigint UNSIGNED NOT NULL,
  `list_id` int UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `list_data`
--

INSERT INTO `list_data` (`id`, `list_id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Normal', 'Normal', 1, '2023-10-04 04:06:24', '2023-10-04 04:06:24'),
(2, 1, 'Partial', 'Partial', 1, '2023-10-04 04:06:24', '2023-10-04 04:06:24'),
(3, 1, 'Missed (Will charge for missed time)', 'Missed (Will charge for missed time)', 1, '2023-10-04 04:06:24', '2023-10-04 04:06:24'),
(4, 1, 'Canceled (Will not be  charged)', 'Canceled (Will not be  charged)', 1, '2023-10-04 04:06:24', '2023-10-04 04:06:24'),
(5, 1, 'Void', 'Void', 1, '2023-10-04 04:06:24', '2023-10-04 04:06:24');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_09_05_224118_create_parents_table', 1),
(7, '2023_09_05_225540_create_api_calls_count_table', 1),
(8, '2023_09_06_201010_laratrust_setup_tables', 1),
(9, '2023_09_08_121921_create_schools_table', 1),
(10, '2023_09_10_183358_create_students_table', 1),
(11, '2023_09_11_171946_create_jobs_table', 1),
(12, '2023_09_12_111004_add_resource_column_to_permissions_table', 1),
(13, '2023_09_17_105332_create_tutors_table', 1),
(14, '2023_09_19_225043_create_package_types_table', 1),
(15, '2023_09_19_225218_create_subjects_table', 1),
(16, '2023_09_19_225331_create_tutoring_locations_table', 1),
(17, '2023_09_20_213205_create_student_tutoring_packages_table', 1),
(18, '2023_09_22_012921_student_tutoring_package_tutor', 1),
(19, '2023_09_22_025414_subject_student_tutoring_package', 1),
(20, '2023_09_24_013317_add_hourly_rate_column_to_tutors_table', 1),
(21, '2023_09_24_070024_create_invoice_package_types_table', 1),
(22, '2023_09_24_084300_create_invoices_table', 1),
(23, '2023_09_24_194305_add_is_completed_column_to_student_tutoring_packages_table', 1),
(24, '2023_09_27_030302_create_sessions_table', 1),
(25, '2023_09_29_005442_change_tutor_hourly_rate_nullable_in_student_tutoring_packages', 1),
(26, '2023_09_30_032141_create_list_data_table', 1),
(27, '2023_10_03_080746_add_tutor_id_to_sessions_table', 1),
(28, '2023_10_04_032213_add_unique_email_in_tutors_table', 2),
(29, '2023_10_06_105954_add_status_in_invoice_package_types_table', 3),
(30, '2023_10_07_014049_add_columns_for_partial_completion_in_sessions_table', 4),
(31, '2023_10_07_021033_add_status_column_to_list_data_table', 5),
(32, '2023_10_10_202055_add_partial_status_columns_to_sessions_table', 6),
(35, '2023_10_11_211854_create_monthly_invoice_packages_table', 7),
(36, '2023_10_12_102100_change_hourly_rate_data_types', 7),
(37, '2023_10_13_103242_create_monthly_invoice_package_subject', 7),
(38, '2023_10_13_103313_create_monthly_invoice_package_tutor', 7),
(39, '2023_10_13_105705_add_montholy_invoice_package_id_in_sessions_table', 8),
(40, '2023_10_14_094830_change_hours_data_type_column', 9),
(41, '2023_10_15_220033_add_columns_to_monthly_invoice_packages_table', 9),
(42, '2023_10_24_103217_create_clients_table', 10),
(43, '2023_10_26_035208_create_taxes_table', 11),
(44, '2023_10_26_090450_add_columns_in_clients_table', 12),
(45, '2023_10_26_090702_add_columns_in_taxes_table', 13),
(47, '2023_10_27_031830_create_line_items_table', 14);

-- --------------------------------------------------------

--
-- Table structure for table `monthly_invoice_packages`
--

CREATE TABLE `monthly_invoice_packages` (
  `id` bigint UNSIGNED NOT NULL,
  `student_id` bigint UNSIGNED NOT NULL,
  `tutoring_location_id` bigint UNSIGNED NOT NULL,
  `notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internal_notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `hourly_rate` decimal(8,2) NOT NULL,
  `tutor_hourly_rate` decimal(8,2) NOT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount_type` smallint UNSIGNED DEFAULT NULL,
  `is_free` tinyint(1) NOT NULL DEFAULT '0',
  `is_score_guaranteed` decimal(8,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `monthly_invoice_packages`
--

INSERT INTO `monthly_invoice_packages` (`id`, `student_id`, `tutoring_location_id`, `notes`, `internal_notes`, `start_date`, `hourly_rate`, `tutor_hourly_rate`, `discount`, `discount_type`, `is_free`, `is_score_guaranteed`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(4001, 3, 1, 'Quaerat autem molest', 'Officia enim consequ', '2023-10-15', '100.00', '25.00', '0.00', NULL, 0, '0.00', 1, 'web', 1, '2023-10-13 23:54:55', '2023-10-13 23:54:55'),
(4002, 2, 1, 'Vitae aut aut eligen', 'Aliqua Voluptate ip', '2023-10-15', '100.00', '25.00', '0.00', NULL, 0, '0.00', 1, 'web', 1, '2023-10-13 23:58:44', '2023-10-13 23:58:44'),
(4003, 3, 1, 'Ullam optio labore', 'Est reprehenderit', '2023-10-16', '100.00', '20.00', '0.00', NULL, 0, '0.00', 1, 'web', 1, '2023-10-14 09:31:21', '2023-10-14 09:31:21'),
(4004, 6, 3, 'Blanditiis suscipit', 'Reprehenderit volup', '2023-10-16', '200.00', '75.00', '0.00', NULL, 0, '0.00', 1, 'web', 1, '2023-10-14 09:36:34', '2023-10-14 09:36:34'),
(4005, 3, 3, 'Dolores praesentium', 'Veniam non aut sed', '2023-10-16', '150.00', '35.00', '0.00', NULL, 0, '0.00', 1, 'web', 1, '2023-10-14 09:43:13', '2023-10-14 09:43:13'),
(4006, 3, 3, 'Consectetur totam qu', 'Doloribus elit repr', '2023-10-16', '100.00', '25.00', '30.00', 1, 0, '0.00', 1, 'web', 1, '2023-10-15 13:01:27', '2023-10-15 13:01:27'),
(4007, 3, 3, 'Nostrud dolore rerum', 'Corrupti quis molli', '2023-10-16', '200.00', '75.00', '100.00', 1, 0, '1.00', 1, 'web', 1, '2023-10-15 13:15:27', '2023-10-15 13:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `monthly_invoice_package_subject`
--

CREATE TABLE `monthly_invoice_package_subject` (
  `monthly_invoice_package_id` bigint UNSIGNED NOT NULL,
  `subject_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `monthly_invoice_package_subject`
--

INSERT INTO `monthly_invoice_package_subject` (`monthly_invoice_package_id`, `subject_id`) VALUES
(4001, 1),
(4001, 2),
(4001, 3),
(4001, 4),
(4002, 2),
(4002, 4),
(4003, 6),
(4003, 7),
(4003, 8),
(4004, 2),
(4004, 3),
(4005, 2),
(4005, 7),
(4005, 8),
(4006, 1),
(4006, 2),
(4006, 6),
(4006, 8),
(4007, 3),
(4007, 5),
(4007, 6),
(4007, 7);

-- --------------------------------------------------------

--
-- Table structure for table `monthly_invoice_package_tutor`
--

CREATE TABLE `monthly_invoice_package_tutor` (
  `monthly_invoice_package_id` bigint UNSIGNED NOT NULL,
  `tutor_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `monthly_invoice_package_tutor`
--

INSERT INTO `monthly_invoice_package_tutor` (`monthly_invoice_package_id`, `tutor_id`) VALUES
(4001, 2),
(4001, 3),
(4002, 2),
(4003, 3),
(4004, 2),
(4005, 4),
(4006, 3),
(4007, 3);

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` bigint UNSIGNED NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `address2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `phone_alternate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_source` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `referral_from_positive_experience_with_tutor` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id`, `first_name`, `last_name`, `email`, `email_verified_at`, `password`, `remember_token`, `secondary_email`, `phone`, `address`, `address2`, `phone_alternate`, `referral_source`, `referral_from_positive_experience_with_tutor`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(5000, 'Kasimir', 'Chambers', 'natyk@mailinator.com', NULL, '$2y$10$uw5p8qwFafKAgmh8zdih6.XvIF1cAY.YmCV2uKtcwohmlLebU56ZG', NULL, NULL, '+1 (643) 334-6917', 'Eveniet reprehender', 'Optio enim pariatur', '+1 (685) 133-3096', 'Illum nisi exceptur', 0, 0, 'web', 1, '2023-10-03 16:55:20', '2023-10-05 17:37:48'),
(5001, 'Mechelle', 'Gutierrez', 'xokosivogo@mailinator.com', NULL, '$2y$10$y/0.dyIug5smUf6r6BNJLOJ/wqu4TqWzuQ.784UYgLCylihlbfvVG', 'NDbuSMnF2EBloiW5Ag6vtMWtm21nvFJIbqwrqxEIbwU018fqRMPzUOLjbNOh', NULL, '+1 (561) 649-2105', 'Vel aut consequat D', 'Vel libero laboris u', '+1 (185) 553-7529', 'Recusandae Ut in ma', 1, 1, 'web', 1, '2023-10-03 16:55:31', '2023-10-03 16:55:31'),
(5002, 'Stacy', 'Gonzalez', 'relalov@mailinator.com', NULL, '$2y$10$UcoLDHUUTVqu.x41mfP61uLjI18Jqf0gFoL29gp.XJdcITRWcHa/m', NULL, NULL, '+1 (816) 651-9763', 'Nostrud expedita fug', 'Incidunt vel qui ut', '+1 (676) 374-5578', 'Qui nemo qui neque q', 0, 1, 'web', 1, '2023-10-03 16:55:44', '2023-10-03 16:55:44'),
(5003, 'Sylvia', 'Garza', 'gezeduzun@mailinator.com', NULL, '$2y$10$T0Gfdwzo2xTUOutJZg.buuWdaW90riAWAKTnrgt/WKXfVx6YDyh4G', NULL, NULL, '+1 (896) 331-8491', 'Veniam laboris eius', 'Autem id ipsam labor', '+1 (503) 507-3559', 'Et velit doloremque', 0, 1, 'web', 1, '2023-10-03 16:57:00', '2023-10-03 16:57:00'),
(5004, 'Nola', 'Underwood', 'ciqybo@mailinator.com', NULL, '$2y$10$Vu8ymZSUQ.pnrWHiYWsHJu9gys23Ikw6QSwHx2sXSdicA9HDRcPM6', 'BfrFg4jaqqVSUqDPBGrS2jtO5iHvXX8itzAXphwubS8N1z6za77ZdTrzKfo1', NULL, '+1 (589) 403-2789', 'At veniam eum aliqu', 'Aut velit ipsam volu', '+1 (601) 846-6376', 'Sed minus impedit N', 0, 1, 'web', 1, '2023-10-03 16:58:59', '2023-10-03 16:58:59'),
(5005, 'Graiden', 'Rhodes', 'gytybulox@mailinator.com', NULL, '$2y$10$H.WCnQnXwg/HvRScX05hP.BJYw1OY.WNQENk7vA24b.yNoXMFecLO', NULL, NULL, '+1 (743) 289-5561', 'Fuga Magna repudian', 'Tenetur lorem sunt', '+1 (259) 148-5288', 'Nisi voluptate vel e', 1, 1, 'web', 1, '2023-10-03 17:00:16', '2023-10-03 17:00:16'),
(5006, 'Hashim', 'Gutierrez', 'zucab@mailinator.com', NULL, '$2y$10$wTqlTAbBWfMWWhWvRutRdOFtzISCbw6IUcB2ZjIVMoRdARoHHyNpq', NULL, NULL, '+1 (811) 693-2934', 'Pariatur Autem aut', 'Inventore adipisicin', '+1 (368) 111-1458', 'Asperiores obcaecati', 0, 1, 'web', 1, '2023-10-03 17:00:21', '2023-10-03 17:00:21');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `resource`, `created_at`, `updated_at`) VALUES
(1, 'parent-index', 'Parent Index', 'Show all parents', 'Parent', '2023-09-06 20:26:21', '2023-09-11 18:54:16'),
(2, 'parent-create', 'Parent Create', 'create or add a new parent', 'Parent', '2023-09-06 20:26:41', '2023-09-11 18:54:34'),
(3, 'parent-edit', 'Parent Edit', 'Edit parent Details', 'Parent', '2023-09-06 20:28:29', '2023-09-11 18:54:37'),
(4, 'parent-show', 'Parent Show', 'show parrent details', 'Parent', '2023-09-06 20:28:48', '2023-09-11 18:54:40'),
(5, 'parent-destroy', 'Parent Destroy', 'Delete parent', 'Parent', '2023-09-06 20:29:08', '2023-09-11 18:54:44'),
(6, 'student-index', 'Student Index', 'Show all students', 'Student', '2023-09-06 20:29:08', '2023-09-11 18:54:52'),
(7, 'student-create', 'Student Create', 'Create or add a new student', 'Student', '2023-09-06 20:29:08', '2023-09-11 18:54:57'),
(8, 'student-edit', 'Student Edit', 'Student Edit', 'Student', '2023-09-06 20:29:08', '2023-09-11 18:55:03'),
(9, 'student-show', 'Student Show', 'Show student detail', 'Student', '2023-09-06 20:29:08', '2023-09-11 18:55:08'),
(10, 'student-destroy', 'Student Destroy', 'Delete student', 'Student', '2023-09-06 20:29:08', '2023-09-11 18:55:11'),
(11, 'school-index', 'School Index', 'Show all schools', 'School', '2023-09-06 20:29:08', '2023-09-11 18:55:25'),
(12, 'school-create', 'School Create', 'Create or add a new school', 'School', '2023-09-06 20:29:08', '2023-09-11 18:55:37'),
(13, 'school-edit', 'School Edit', 'Edit school detail', 'School', '2023-09-06 20:29:08', '2023-09-11 18:55:43'),
(14, 'school-show', 'School Show', 'Show school detail', 'School', '2023-09-06 20:29:08', '2023-09-11 18:55:51'),
(15, 'school-destroy', 'School Destroy', 'Delete school', 'School', '2023-09-06 20:29:08', '2023-09-11 18:55:56'),
(16, 'tutor-index', 'Tutor Index', 'Tutor Index', 'Tutor', '2023-09-16 14:54:45', '2023-09-16 14:54:45'),
(17, 'tutor-create', 'Tutor Create', 'Create or add a new tutor', 'Tutor', '2023-09-06 20:29:08', '2023-09-06 20:29:08'),
(18, 'tutor-edit', 'Tutor Edit', 'Edit tutor detail', 'Tutor', '2023-09-06 20:29:08', '2023-09-06 20:29:08'),
(19, 'tutor-show', 'Tutor Show', 'Show tutor detail', 'Tutor', '2023-09-06 20:29:08', '2023-09-06 20:29:08'),
(20, 'tutor-destroy', 'Tutor Destroy', 'Delete tutor', 'Tutor', '2023-09-06 20:29:08', '2023-09-06 20:29:08'),
(21, 'proctor-index', 'Proctor Index', 'Show all proctors', 'Proctor', '2023-09-16 20:04:40', '2023-09-16 20:04:40'),
(22, 'proctor-create', 'Proctor Create', 'Create or add a new proctor', 'Proctor', '2023-09-16 20:04:40', '2023-09-16 20:04:40'),
(23, 'proctor-edit', 'Proctor Edit', 'Edit proctor detail', 'Proctor', '2023-09-16 20:04:40', '2023-09-16 20:04:40'),
(24, 'proctor-show', 'Proctor Show', 'Show proctor detail', 'Proctor', '2023-09-16 20:04:40', '2023-09-16 20:04:40'),
(25, 'proctor-destroy', 'Proctor Destroy', 'Delete proctor', 'Proctor', '2023-09-16 20:04:40', '2023-09-16 20:04:40'),
(26, 'student_tutoring_package-index', 'Student Tutoring Package Index', 'Show all packages', 'Student Tutoring Package', '2023-09-19 06:27:37', '2023-09-19 06:27:37'),
(27, 'student_tutoring_package-create', 'Student Tutoring Package Create', 'Create or add a new package', 'Student Tutoring Package', '2023-09-19 06:27:37', '2023-09-19 06:27:37'),
(28, 'student_tutoring_package-edit', 'Student Tutoring Package Edit', 'Edit package detail', 'Student Tutoring Package', '2023-09-19 06:27:37', '2023-09-19 06:27:37'),
(29, 'student_tutoring_package-show', 'Student Tutoring Package Show', 'Show package detail', 'Student Tutoring Package', '2023-09-19 06:27:37', '2023-09-19 06:27:37'),
(30, 'student_tutoring_package-destroy', 'Student Tutoring Package Destroy', 'Delete package', 'Student Tutoring Package', '2023-09-19 06:27:37', '2023-09-19 06:27:37'),
(31, 'subject-index', 'Subject Index', 'Show all subjects', 'Subject', '2023-09-19 06:28:24', '2023-09-19 06:28:24'),
(32, 'subject-create', 'Subject Create', 'Create or add a new subject', 'Subject', '2023-09-19 06:28:24', '2023-09-19 06:28:24'),
(33, 'subject-edit', 'Subject Edit', 'Edit subject detail', 'Subject', '2023-09-19 06:28:24', '2023-09-19 06:28:24'),
(34, 'subject-show', 'Subject Show', 'Show subject detail', 'Subject', '2023-09-19 06:28:24', '2023-09-19 06:28:24'),
(35, 'subject-destroy', 'Subject Destroy', 'Delete subject', 'Subject', '2023-09-19 06:28:24', '2023-09-19 06:28:24'),
(36, 'tutoring_location-index', 'Tutoring Location Index', 'Show all tutoring \n locations', 'Tutoring Location', '2023-09-19 06:29:08', '2023-09-19 06:29:08'),
(37, 'tutoring_location-create', 'Tutoring Location Create', 'Create or add a new tutoring location', 'Tutoring Location', '2023-09-19 06:29:08', '2023-09-19 06:29:08'),
(38, 'tutoring_location-edit', 'Tutoring Location Edit', 'Edit tutoring location detail', 'Tutoring Location', '2023-09-19 06:29:08', '2023-09-19 06:29:08'),
(39, 'tutoring_location-show', 'Tutoring Location Show', 'Show Tutoring location detail', 'Tutoring Location', '2023-09-19 06:29:08', '2023-09-19 06:29:08'),
(40, 'tutoring_location-destroy', 'Location Tutoring Destroy', 'Delete tutoring location', 'Tutoring Location', '2023-09-19 06:29:08', '2023-09-19 06:29:08'),
(41, 'tutoring_package_type-index', 'Tutoring Package Type Index', 'Show all Tutoring  package_types', 'Tutoring Package Type', '2023-09-19 07:41:29', '2023-09-19 07:41:29'),
(42, 'tutoring_package_type-create', 'Tutoring Package Type Create', 'Create or add a new package_type', 'Tutoring Package Type', '2023-09-19 07:41:29', '2023-09-19 07:41:29'),
(43, 'tutoring_package_type-edit', 'Tutoring Package Type Edit', 'Edit Tutoring  package_type detail', 'Tutoring Package Type', '2023-09-19 07:41:29', '2023-09-19 07:41:29'),
(44, 'tutoring_package_type-show', 'Tutoring Package Type Show', 'Show Tutoring  package_type detail', 'Tutoring Package Type', '2023-09-19 07:41:29', '2023-09-19 07:41:29'),
(45, 'tutoring_package_type-destroy', 'Tutoring Package Type Destroy', 'Delete Tutoring  package_type', 'Tutoring Package Type', '2023-09-19 07:41:29', '2023-09-19 07:41:29'),
(46, 'package_type-index', 'Package Type Index', 'Show all package types', 'Package Type', '2023-09-23 16:26:02', '2023-09-23 16:26:02'),
(47, 'package_type-create', 'Package Type Create', 'Create or add a new package type', 'Package Type', '2023-09-23 16:26:02', '2023-09-23 16:26:02'),
(48, 'package_type-edit', 'Package Type Edit', 'Edit package type detail', 'Package Type', '2023-09-23 16:26:02', '2023-09-23 16:26:02'),
(49, 'package_type-show', 'Package Type Show', 'Show package type detail', 'Package Type', '2023-09-23 16:26:02', '2023-09-23 16:26:02'),
(50, 'package_type-destroy', 'Package Type Destroy', 'Delete package type', 'Package Type', '2023-09-23 16:26:02', '2023-09-23 16:26:02'),
(51, 'invoice_package_type-index', 'Invoice Package Type Index', 'Show all package types', 'Invoice Package Type', '2023-09-24 02:05:31', '2023-09-24 02:05:31'),
(52, 'invoice_package_type-create', 'Invoice Package Type Create', 'Create or add a new invoice package type', 'Invoice Package Type', '2023-09-24 02:05:31', '2023-09-24 02:05:31'),
(53, 'invoice_package_type-edit', 'Invoice Package Type Edit', 'Edit invoice package type detail', 'Invoice Package Type', '2023-09-24 02:05:31', '2023-09-24 02:05:31'),
(54, 'invoice_package_type-show', 'Invoice Package Type Show', 'Show invoice package type detail', 'Invoice Package Type', '2023-09-24 02:05:31', '2023-09-24 02:05:31'),
(55, 'invoice_package_type-destroy', 'Invoice Package Type Destroy', 'Delete invoice invoice package type', 'Invoice Package Type', '2023-09-24 02:05:31', '2023-09-24 02:05:31'),
(56, 'invoice-index', 'Invoice Index', 'Show all invoices', 'Invoice', '2023-09-24 03:51:08', '2023-09-24 03:51:08'),
(57, 'invoice-create', 'Invoice Create', 'Create or add a new invoice', 'Invoice', '2023-09-24 03:51:08', '2023-09-24 03:51:08'),
(58, 'invoice-edit', 'Invoice Edit', 'Edit invoice detail', 'Invoice', '2023-09-24 03:51:08', '2023-09-24 03:51:08'),
(59, 'invoice-show', 'Invoice Show', 'Show invoice detail', 'Invoice', '2023-09-24 03:51:08', '2023-09-24 03:51:08'),
(60, 'invoice-destroy', 'Invoice Destroy', 'Delete invoice', 'Invoice', '2023-09-24 03:51:08', '2023-09-24 03:51:08'),
(61, 'tutor_dashboard-index', 'Tutor Dashboard', 'Tutor Dashboard', 'Others', '2023-09-26 10:01:51', '2023-09-26 10:01:51'),
(62, 'session-index', 'Session Index', 'Session Index', 'Session', '2023-09-28 11:09:31', '2023-09-28 11:09:31'),
(63, 'session-create', 'Session Create', 'Session Create', 'Session', '2023-09-28 11:09:47', '2023-09-28 11:09:47'),
(64, 'session-show', 'Session Show', 'Session Show', 'Session', '2023-09-29 06:39:00', '2023-09-29 06:39:00'),
(65, 'session-edit', 'Session Edit', 'Session Edit', 'Session', '2023-09-29 12:50:38', '2023-09-29 12:51:13'),
(66, 'session-destroy', 'Session Destroy', 'Session Destroy', 'Session', '2023-09-29 12:50:58', '2023-09-29 12:50:58'),
(67, 'super_admin-dashboard', 'Super Admin Dashboard', 'Super Admin Dashboard', 'Super Admin Dashboard', '2023-10-05 17:09:19', '2023-10-05 17:09:19'),
(68, 'monthly_invoice_package-index', 'Monthly Invoice Package Index', 'Show all Monthly Invoice Packages', 'Monthly Invoice Package', '2023-10-12 06:29:33', '2023-10-12 06:29:33'),
(69, 'monthly_invoice_package-create', 'Monthly Invoice Package Create', 'Create or add a new Monthly Invoice Package', 'Monthly Invoice Package', '2023-10-12 06:29:33', '2023-10-12 06:29:33'),
(70, 'monthly_invoice_package-edit', 'Monthly Invoice Package Edit', 'Edit Monthly Invoice Package detail', 'Monthly Invoice Package', '2023-10-12 06:29:33', '2023-10-12 06:29:33'),
(71, 'monthly_invoice_package-show', 'Monthly Invoice Package Show', 'Show Monthly Invoice Package detail', 'Monthly Invoice Package', '2023-10-12 06:29:33', '2023-10-12 06:29:33'),
(72, 'monthly_invoice_package-destroy', 'Monthly Invoice Package Destroy', 'Delete Monthly Invoice Package', 'Monthly Invoice Package', '2023-10-12 06:29:33', '2023-10-12 06:29:33'),
(73, 'non_package_invoice-create', 'Non-Package Invoice Create', 'Non package invoice create', 'Others', '2023-10-24 12:50:58', '2023-10-24 12:50:58'),
(74, 'client-index', 'Client Index', 'Show all Clients', 'Client', '2023-10-24 06:11:28', '2023-10-24 06:11:28'),
(75, 'client-create', 'Client Create', 'Create or add a new Client', 'Client', '2023-10-24 06:11:28', '2023-10-24 06:11:28'),
(76, 'client-edit', 'Client Edit', 'Edit Client detail', 'Client', '2023-10-24 06:11:28', '2023-10-24 06:11:28'),
(77, 'client-show', 'Client Show', 'Show Client detail', 'Client', '2023-10-24 06:11:28', '2023-10-24 06:11:28'),
(78, 'client-destroy', 'Client Destroy', 'Delete Client', 'Client', '2023-10-24 06:11:28', '2023-10-24 06:11:28'),
(79, 'tax-index', 'Tax Index', 'Show all Taxs', 'Tax', '2023-10-26 03:57:26', '2023-10-26 03:57:26'),
(80, 'tax-create', 'Tax Create', 'Create or add a new Tax', 'Tax', '2023-10-26 03:57:26', '2023-10-26 03:57:26'),
(81, 'tax-edit', 'Tax Edit', 'Edit Tax detail', 'Tax', '2023-10-26 03:57:26', '2023-10-26 03:57:26'),
(82, 'tax-show', 'Tax Show', 'Show Tax detail', 'Tax', '2023-10-26 03:57:26', '2023-10-26 03:57:26'),
(83, 'tax-destroy', 'Tax Destroy', 'Delete Tax', 'Tax', '2023-10-26 03:57:26', '2023-10-26 03:57:26'),
(84, 'line_item-index', 'LineItem Index', 'Show all LineItems', 'LineItem', '2023-10-27 03:21:00', '2023-10-27 03:21:00'),
(85, 'line_item-create', 'LineItem Create', 'Create or add a new LineItem', 'LineItem', '2023-10-27 03:21:00', '2023-10-27 03:21:00'),
(86, 'line_item-edit', 'LineItem Edit', 'Edit LineItem detail', 'LineItem', '2023-10-27 03:21:00', '2023-10-27 03:21:00'),
(87, 'line_item-show', 'LineItem Show', 'Show LineItem detail', 'LineItem', '2023-10-27 03:21:00', '2023-10-27 03:21:00'),
(88, 'line_item-destroy', 'LineItem Destroy', 'Delete LineItem', 'LineItem', '2023-10-27 03:21:00', '2023-10-27 03:21:00');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(77, 1),
(78, 1),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(83, 1),
(84, 1),
(85, 1),
(86, 1),
(87, 1),
(88, 1),
(1, 3),
(3, 3),
(4, 3),
(6, 3),
(8, 3),
(9, 3),
(56, 3),
(59, 3),
(1, 4),
(4, 4),
(6, 4),
(8, 4),
(9, 4),
(16, 4),
(19, 4),
(56, 4),
(59, 4),
(6, 5),
(9, 5),
(16, 5),
(18, 5),
(19, 5),
(61, 5),
(62, 5),
(63, 5),
(64, 5),
(65, 5);

-- --------------------------------------------------------

--
-- Table structure for table `permission_user`
--

CREATE TABLE `permission_user` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `user_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'super-admin', 'Super Admin', 'Super Admin', '2023-09-06 20:30:19', '2023-10-03 16:54:56'),
(2, 'admin', 'Admin', 'Role of Admin', '2023-09-09 20:46:16', '2023-09-09 20:46:16'),
(3, 'parent', 'Parent', 'Role of Parent', '2023-09-09 20:46:50', '2023-09-09 20:46:50'),
(4, 'student', 'Student', 'Role of student', '2023-09-09 20:47:08', '2023-09-09 20:47:08'),
(5, 'tutor', 'Tutor', 'Role of tutor', '2023-09-09 20:47:32', '2023-09-09 20:47:32'),
(6, 'proctor', 'Proctor', 'Role of Proctor', '2023-09-09 20:47:53', '2023-09-09 20:47:53'),
(7, 'client', 'Client', 'Role of client', '2023-09-09 20:48:23', '2023-09-09 20:48:23'),
(8, 'developer', 'Developer', 'Developers', '2023-09-10 18:48:10', '2023-09-10 19:06:46');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `role_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `user_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`role_id`, `user_id`, `user_type`) VALUES
(1, 1, 'App\\Models\\User'),
(3, 5000, 'App\\Models\\ParentUser'),
(3, 5001, 'App\\Models\\ParentUser'),
(3, 5002, 'App\\Models\\ParentUser'),
(3, 5003, 'App\\Models\\ParentUser'),
(3, 5004, 'App\\Models\\ParentUser'),
(3, 5005, 'App\\Models\\ParentUser'),
(3, 5006, 'App\\Models\\ParentUser'),
(4, 1, 'App\\Models\\Student'),
(4, 2, 'App\\Models\\Student'),
(4, 3, 'App\\Models\\Student'),
(4, 4, 'App\\Models\\Student'),
(4, 5, 'App\\Models\\Student'),
(4, 6, 'App\\Models\\Student'),
(4, 7, 'App\\Models\\Student'),
(4, 8, 'App\\Models\\Student'),
(5, 1, 'App\\Models\\Tutor'),
(5, 2, 'App\\Models\\Tutor'),
(5, 3, 'App\\Models\\Tutor'),
(5, 4, 'App\\Models\\Tutor');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` bigint UNSIGNED NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `name`, `address`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'Octavia Barber', 'Ipsum quod adipisic', 1, 'web', 1, '2023-10-03 17:00:45', '2023-10-03 17:00:45'),
(2, 'Chantale Farmer', 'Voluptate incidunt', 1, 'web', 1, '2023-10-03 17:00:55', '2023-10-03 17:00:55'),
(3, 'Fallon Hendrix', 'Lorem reprehenderit', 1, 'web', 1, '2023-10-03 17:00:59', '2023-10-03 17:00:59'),
(4, 'Zelenia Beard', 'Do sed rerum odit mo', 1, 'web', 1, '2023-10-03 17:01:02', '2023-10-03 17:01:02'),
(5, 'Hashim Briggs', 'Praesentium quis dol', 1, 'web', 1, '2023-10-03 17:01:06', '2023-10-03 17:01:06'),
(6, 'Marshall Clay', 'In nesciunt corrupt', 0, 'web', 1, '2023-10-03 17:01:09', '2023-10-05 17:41:56');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` bigint UNSIGNED NOT NULL,
  `student_tutoring_package_id` bigint UNSIGNED DEFAULT NULL,
  `monthly_invoice_package_id` bigint UNSIGNED DEFAULT NULL,
  `tutoring_location_id` bigint UNSIGNED NOT NULL,
  `tutor_id` bigint UNSIGNED DEFAULT NULL,
  `scheduled_date` datetime NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `pre_session_notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_completion_code` smallint UNSIGNED DEFAULT NULL,
  `attended_duration` time DEFAULT NULL,
  `charge_for_missed_session` tinyint(1) NOT NULL DEFAULT '0',
  `charged_missed_session` time DEFAULT NULL,
  `how_was_session` int DEFAULT NULL,
  `student_parent_session_notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `homework` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internal_notes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag_session` tinyint(1) DEFAULT NULL,
  `home_work_completed` tinyint(1) DEFAULT NULL,
  `attended_start_time` time DEFAULT NULL,
  `attended_end_time` time DEFAULT NULL,
  `charge_missed_time` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `student_tutoring_package_id`, `monthly_invoice_package_id`, `tutoring_location_id`, `tutor_id`, `scheduled_date`, `start_time`, `end_time`, `pre_session_notes`, `session_completion_code`, `attended_duration`, `charge_for_missed_session`, `charged_missed_session`, `how_was_session`, `student_parent_session_notes`, `homework`, `internal_notes`, `flag_session`, `home_work_completed`, `attended_start_time`, `attended_end_time`, `charge_missed_time`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(5000, 3000, NULL, 2, 4, '2023-10-03 00:00:00', '13:00:00', '15:03:00', NULL, 1, NULL, 0, NULL, 1, 'Consectetur culpa e', 'Eu aut dolor et accu', 'Labore qui et placea', 1, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-04 03:03:24', '2023-10-04 03:03:24'),
(5001, 3000, NULL, 2, 4, '2023-10-05 00:00:00', '18:00:00', '19:30:00', NULL, 1, NULL, 0, NULL, 1, 'Ratione sit dolor q', 'Necessitatibus et re', 'Incidunt earum mole', 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-04 08:04:43', '2023-10-04 08:04:43'),
(5002, 3000, NULL, 1, 4, '2023-10-01 00:00:00', '17:00:00', '19:42:00', NULL, 1, NULL, 0, NULL, 1, 'Sed pariatur Itaque', 'Rerum earum facere t', 'Possimus ut volupta', 0, 1, NULL, NULL, 0, 1, 'tutor', 4, '2023-10-04 13:42:39', '2023-10-04 13:42:39'),
(5003, 3001, NULL, 1, 2, '2023-10-08 00:00:00', '09:00:00', '10:50:00', NULL, 5, NULL, 0, NULL, 1, 'Qui dolor debitis vo', 'Voluptates repellend', 'Nobis quo rerum quib', 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-05 16:42:45', '2023-10-05 16:42:45'),
(5004, 3001, NULL, 2, 2, '2023-10-02 00:00:00', '02:00:00', '03:00:00', NULL, 1, NULL, 0, NULL, 1, 'Vitae obcaecati reru', 'Ea quidem molestiae', 'Accusantium maiores', 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-06 16:23:56', '2023-10-06 16:23:56'),
(5005, 3001, NULL, 1, 3, '2023-10-10 00:00:00', '15:00:00', '16:00:00', NULL, 2, NULL, 0, NULL, 1, 'Inventore ea aliqua', 'Occaecat ut et tenet', 'Nisi cum aspernatur', 1, 1, '15:10:00', '15:30:00', 0, 1, 'web', 1, '2023-10-10 10:38:50', '2023-10-10 10:38:50'),
(5006, 3001, NULL, 1, 3, '2023-10-10 00:00:00', '13:00:00', '14:00:00', NULL, 2, NULL, 0, NULL, 1, 'Laboriosam eaque op', 'Fugiat facilis ullam', 'Saepe corrupti ea i', 1, 0, '13:10:00', '13:30:00', 1, 1, 'web', 1, '2023-10-10 11:12:00', '2023-10-10 11:12:00'),
(5007, 3001, NULL, 1, 3, '2023-10-04 00:00:00', '16:00:00', '17:00:00', NULL, 1, NULL, 0, NULL, 1, 'Inventore ea aliqua', 'Occaecat ut et tenet', 'Nisi cum aspernatur', 1, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-10 14:14:41', '2023-10-10 16:37:55'),
(5008, 3001, NULL, 1, 3, '2023-10-02 00:00:00', '16:00:00', '17:00:00', NULL, 2, NULL, 0, NULL, 1, 'Inventore ea aliqua', 'Occaecat ut et tenet', 'Nisi cum aspernatur', 1, 1, '16:10:00', '16:40:00', 0, 1, 'web', 1, '2023-10-10 14:16:06', '2023-10-10 14:16:06'),
(5009, NULL, 4004, 3, 3, '2023-10-12 00:00:00', '21:00:00', '22:00:00', NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-14 11:08:35', '2023-10-14 11:08:35'),
(5010, NULL, 4002, 3, 2, '2023-10-12 00:00:00', '20:00:00', '21:00:00', NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-14 11:11:32', '2023-10-14 11:11:32'),
(5011, NULL, 4003, 1, 2, '2023-10-18 00:00:00', '21:00:00', '22:00:00', NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-14 11:13:23', '2023-10-14 11:13:23'),
(5012, NULL, 4002, 1, 3, '2023-10-12 00:00:00', '21:00:00', '22:00:00', NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-14 11:15:16', '2023-10-14 11:15:16'),
(5013, NULL, 4003, 3, 3, '2023-10-11 00:00:00', '21:00:00', '22:00:00', NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-14 11:27:09', '2023-10-14 11:27:09'),
(5014, NULL, 4005, 3, 3, '2023-10-09 00:00:00', '15:00:00', '16:00:00', NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-15 05:48:31', '2023-10-15 05:48:31'),
(5015, 3004, NULL, 3, 2, '2023-10-06 00:00:00', '02:00:00', '04:00:00', NULL, 1, NULL, 0, NULL, 1, NULL, NULL, NULL, 0, 1, NULL, NULL, 0, 1, 'web', 1, '2023-10-15 16:14:09', '2023-10-15 16:14:09');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint UNSIGNED NOT NULL,
  `school_id` bigint UNSIGNED NOT NULL,
  `parent_id` bigint UNSIGNED DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_known` tinyint(1) DEFAULT NULL,
  `testing_accommodation` tinyint(1) DEFAULT NULL,
  `testing_accommodation_nature` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `official_baseline_act_score` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `official_baseline_sat_score` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_anxiety_challenge` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `school_id`, `parent_id`, `first_name`, `last_name`, `email`, `email_verified_at`, `password`, `remember_token`, `email_known`, `testing_accommodation`, `testing_accommodation_nature`, `official_baseline_act_score`, `official_baseline_sat_score`, `test_anxiety_challenge`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 1, 5002, 'Yuli', 'Cohen', 'vohokyhegy@mailinator.com', NULL, '$2y$10$aE9gd1WO8rjZvvcVjAxffeL/.VlPmLKrngN4ppkjBaaLaNyGNwU3G', NULL, 1, 1, 'Fugit laboris nesci', 'Mollit reprehenderit', 'Reprehenderit est d', 1, 1, 'web', 1, '2023-10-03 17:03:34', '2023-10-03 17:18:08'),
(2, 2, NULL, 'Zachery', 'Benton', 'vazeh@mailinator.com', NULL, '$2y$10$MByfNuhOD3WdkQ93OlhVnu5CFE7ohVIdLF310X3/cbt5quNRxezcW', '0DNN7VK0q6Su3ZlUL3Y7N6HuOiG35O1a0TMo6KF1zYtn77ygP5YPaxVVgmPg', 0, 1, 'Ducimus in tempore', 'Eaque pariatur Culp', 'Ipsam voluptatem si', 1, 1, 'web', 1, '2023-10-03 17:03:50', '2023-10-03 17:18:00'),
(3, 4, 5001, 'Garth', 'Steele', 'mycupabeh@mailinator.com', NULL, '$2y$10$TExDgBkqXJkonHTyWZDrmOgaOre5jMl/s58PRdBSocFYAY4x/uVjK', 'vqgnCEsWdsTJ4lZTJJXGsDKyd63tJlolwH6tPrTnE8fDgVcVYvhlKPYV2HAF', 1, 1, 'Laborum Ea ullamco', 'Anim tempor ducimus', 'Repudiandae voluptat', 0, 1, 'web', 1, '2023-10-03 17:04:09', '2023-10-03 17:04:09'),
(4, 5, 5000, 'Kiara', 'Shaffer', 'xudepywubo@mailinator.com', NULL, '$2y$10$L0dcBhBiNAZMWcvisZDGquhZeZfllNa4iCrXesWuwEi2fXXYUAnJe', NULL, 1, 0, 'Odit amet anim dolo', 'Modi corrupti adipi', 'Qui id ut veritatis', 1, 0, 'web', 1, '2023-10-03 17:04:25', '2023-10-06 01:04:27'),
(5, 6, 5003, 'Kevin', 'Wagner', 'wamibaxer@mailinator.com', NULL, '$2y$10$NVGf53uENur28kAO1waCyewZucFEra88yszopwbdV0qOtA8elKflO', NULL, 0, 1, 'Iure veniam a velit', 'Porro repudiandae la', 'Illum exercitation', 1, 1, 'web', 1, '2023-10-03 17:04:39', '2023-10-03 17:04:39'),
(6, 3, 5004, 'Hope', 'Talley', 'qimoqy@mailinator.com', NULL, '$2y$10$323ATys4iQJNhEl/yabXquixBHQ9AVmrWtN4Uu1snEPxXjFOAdgWC', NULL, 0, 0, 'Laboris minim dolore', 'Quaerat reiciendis v', 'Minima alias ea minu', 1, 1, 'web', 1, '2023-10-03 17:04:55', '2023-10-03 17:04:55'),
(7, 4, 5003, 'Heidi', 'Padilla', 'zewiby@mailinator.com', NULL, '$2y$10$J0vCkfCrMf5hL1gJGgjW6uCO.LzyNSohlTixSGz4kGJtL/jGlFNoO', NULL, 1, 0, 'Placeat voluptatem', 'Modi accusamus repre', 'Harum suscipit venia', 0, 1, 'web', 1, '2023-10-03 17:20:03', '2023-10-03 17:20:03'),
(8, 1, 5001, 'Kirby', 'Norton', 'deguze@mailinator.com', NULL, '$2y$10$f3lmDyw.vfYQ6pdNim4njem6eKrrDUkN6XqsPKMrI3NEkPCUITV5y', NULL, 0, 0, 'Numquam eos harum v', 'Iusto doloremque iru', 'Deserunt veritatis i', 0, 1, 'web', 1, '2023-10-04 13:05:26', '2023-10-04 13:05:26');

-- --------------------------------------------------------

--
-- Table structure for table `student_tutoring_packages`
--

CREATE TABLE `student_tutoring_packages` (
  `id` bigint UNSIGNED NOT NULL,
  `student_id` bigint UNSIGNED NOT NULL,
  `tutoring_package_type_id` bigint UNSIGNED NOT NULL,
  `tutoring_location_id` bigint UNSIGNED NOT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `internal_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `hours` decimal(4,2) UNSIGNED NOT NULL DEFAULT '0.00',
  `hourly_rate` decimal(8,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(8,2) DEFAULT '0.00',
  `discount_type` smallint UNSIGNED DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `tutor_hourly_rate` decimal(8,2) DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_tutoring_packages`
--

INSERT INTO `student_tutoring_packages` (`id`, `student_id`, `tutoring_package_type_id`, `tutoring_location_id`, `notes`, `internal_notes`, `hours`, `hourly_rate`, `discount`, `discount_type`, `start_date`, `tutor_hourly_rate`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(3000, 2, 1, 2, 'Molestiae ipsum et', 'Ratione fugiat nihil', '25.00', '120.00', '5.00', 1, '2023-10-05', NULL, 0, 'web', 1, '2023-10-03 17:37:43', '2023-10-06 01:17:59'),
(3001, 4, 2, 1, 'Numquam fugiat aliq', 'Exercitationem praes', '50.00', '200.00', '150.00', 1, '2023-10-06', '20.00', 1, 'web', 1, '2023-10-04 02:36:16', '2023-10-04 12:39:52'),
(3004, 6, 1, 1, 'Totam duis repellend', 'Consectetur nihil q', '25.00', '70.00', '2.00', 2, '2023-10-12', NULL, 1, 'web', 1, '2023-10-12 01:13:19', '2023-10-12 01:13:19');

-- --------------------------------------------------------

--
-- Table structure for table `student_tutoring_package_subject`
--

CREATE TABLE `student_tutoring_package_subject` (
  `subject_id` bigint UNSIGNED NOT NULL,
  `student_tutoring_package_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_tutoring_package_subject`
--

INSERT INTO `student_tutoring_package_subject` (`subject_id`, `student_tutoring_package_id`) VALUES
(1, 3000),
(2, 3000),
(1, 3001),
(4, 3001),
(2, 3004);

-- --------------------------------------------------------

--
-- Table structure for table `student_tutoring_package_tutor`
--

CREATE TABLE `student_tutoring_package_tutor` (
  `tutor_id` bigint UNSIGNED NOT NULL,
  `student_tutoring_package_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_tutoring_package_tutor`
--

INSERT INTO `student_tutoring_package_tutor` (`tutor_id`, `student_tutoring_package_id`) VALUES
(4, 3000),
(3, 3001),
(2, 3001),
(2, 3004);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint UNSIGNED NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'ACT', 1, 'web', 1, '2023-10-03 17:26:51', '2023-10-03 17:26:51'),
(2, 'SAT', 1, 'web', 1, '2023-10-03 17:26:57', '2023-10-03 17:26:57'),
(3, 'MCAT', 1, 'web', 1, '2023-10-03 17:27:02', '2023-10-03 17:27:02'),
(4, 'ECAT', 1, 'web', 1, '2023-10-03 17:27:12', '2023-10-03 17:27:12'),
(5, 'Math', 0, 'web', 1, '2023-10-03 17:27:21', '2023-10-06 00:55:58'),
(6, 'ICT', 1, 'web', 1, '2023-10-14 09:04:34', '2023-10-14 09:04:34'),
(7, 'ICT', 1, 'web', 1, '2023-10-14 09:11:19', '2023-10-14 09:11:19'),
(8, 'AAT', 1, 'web', 1, '2023-10-14 09:12:14', '2023-10-14 09:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `taxes`
--

CREATE TABLE `taxes` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `taxes`
--

INSERT INTO `taxes` (`id`, `name`, `value`, `created_at`, `updated_at`, `status`, `auth_guard`, `added_by`) VALUES
(1, 'GST', '16.00', '2023-10-25 22:58:59', '2023-10-25 22:58:59', 1, '', 0),
(2, 'Withholding', '1.00', '2023-10-25 22:59:16', '2023-10-25 22:59:16', 1, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tutoring_locations`
--

CREATE TABLE `tutoring_locations` (
  `id` bigint UNSIGNED NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tutoring_locations`
--

INSERT INTO `tutoring_locations` (`id`, `name`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'Home', 1, 'web', 1, '2023-10-03 17:27:31', '2023-10-03 17:27:31'),
(2, 'Onsite', 1, 'web', 1, '2023-10-03 17:27:40', '2023-10-03 17:36:58'),
(3, 'Zoom', 1, 'web', 1, '2023-10-03 17:27:44', '2023-10-06 00:56:43'),
(4, 'Teams', 0, 'web', 1, '2023-10-06 01:06:34', '2023-10-06 01:06:38');

-- --------------------------------------------------------

--
-- Table structure for table `tutoring_package_types`
--

CREATE TABLE `tutoring_package_types` (
  `id` bigint UNSIGNED NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hours` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tutoring_package_types`
--

INSERT INTO `tutoring_package_types` (`id`, `name`, `hours`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`) VALUES
(1, '24 Hours', 25, 1, 'web', 1, '2023-10-03 17:26:24', '2023-10-03 17:26:24'),
(2, '48 hours', 50, 1, 'web', 1, '2023-10-03 17:26:34', '2023-10-03 17:26:34'),
(3, '72 hours', 75, 0, 'web', 1, '2023-10-03 17:26:44', '2023-10-06 00:53:08');

-- --------------------------------------------------------

--
-- Table structure for table `tutors`
--

CREATE TABLE `tutors` (
  `id` bigint UNSIGNED NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resume` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth_guard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `hourly_rate` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tutors`
--

INSERT INTO `tutors` (`id`, `first_name`, `last_name`, `email`, `email_verified_at`, `password`, `remember_token`, `secondary_email`, `phone`, `secondary_phone`, `picture`, `resume`, `start_date`, `status`, `auth_guard`, `added_by`, `created_at`, `updated_at`, `hourly_rate`) VALUES
(1, 'Blair', 'Carey', 'patateqe@mailinator.com', NULL, '$2y$10$owo.PuSTO/k2Uo/oDtxDwewRg23bHQFOmcQasxcP08uQarcXqUw/W', NULL, 'patateqe@mailinator.com', '+1 (818) 274-6042', '+1 (818) 274-6042', NULL, NULL, '2023-10-04', 1, 'web', 1, '2023-10-03 17:20:20', '2023-10-15 15:57:26', '52.00'),
(2, 'Erich', 'Vargas', 'dyregi@mailinator.com', NULL, '$2y$10$yi.sBOIYgmjI7cmyoZ9oB.wMsXb7M0RmEjacPqOzw.iHJ51DXgHl6', 'WF6eKUPZfQFLhdgv21ezJYJUiD8HgBnWlxMj4OpoVoV77ZjQM3DDzq1NWEUw', 'dyregi@mailinator.com', '+1 (482) 314-6494', '+1 (482) 314-6494', NULL, NULL, '2023-10-15', 1, 'web', 1, '2023-10-03 17:20:27', '2023-10-03 17:20:27', '97.00'),
(3, 'Coby', 'Norris', 'tilapasqit@mailinator.com', NULL, '$2y$10$q00k6zpsUq7Us1h97IjmOOr3RVF7e3dcnOCvOPSBo.4H83uCltoru', 'pAnZejvPf7oSCsIX6C1bLOxFNiE9keUTsWcPWpGFSE9tJxYOAt3icPCzANvh', 'tilapaqit@mailinator.com', '+1 (363) 194-4634', '+1 (363) 194-4634', NULL, NULL, '2023-10-16', 1, 'web', 1, '2023-10-03 17:20:35', '2023-10-03 17:22:52', '85.00'),
(4, 'MacKenzie', 'Berger', 'tilapaqit@mailinator.com', NULL, '$2y$10$/BRgkoWAf0I1U5FpBiAzsuLjMplJU9ItoUbFgl4nhYJZYfexo4TeK', 'Ghp11V96vgS1Sbwy7jfDp3t8FDwYQPXTPaIsVGrVduVccTTdecDbu2ovswDp', 'kusati@mailinator.com', '+1 (837) 551-3671', '+1 (837) 551-3671', NULL, NULL, '1996-08-22', 1, 'web', 1, '2023-10-03 17:21:11', '2023-10-03 17:25:08', '25.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Super', 'Admin', 'admin@admin.com', '2023-10-03 16:51:29', '$2y$10$el3QiiYVTeNv6ghGHzn9mOA0pwWAjFZoC6WLr8HJ02Z3/h5qHLYDq', 'EFuuFuKmUZU2uIuaQ98Jdqoi2EW9kGdm43PNEIqFWmg3y4Xw09aWQO2GMv9Z', '2023-10-03 16:51:29', '2023-10-03 16:51:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api_calls_count`
--
ALTER TABLE `api_calls_count`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoices_invoice_package_type_id_foreign` (`invoice_package_type_id`);

--
-- Indexes for table `invoice_package_types`
--
ALTER TABLE `invoice_package_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `line_items`
--
ALTER TABLE `line_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `list_data`
--
ALTER TABLE `list_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `list_data_list_id_index` (`list_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthly_invoice_packages`
--
ALTER TABLE `monthly_invoice_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `monthly_invoice_packages_student_id_foreign` (`student_id`),
  ADD KEY `monthly_invoice_packages_tutoring_location_id_foreign` (`tutoring_location_id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `parents_email_unique` (`email`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `permission_user`
--
ALTER TABLE `permission_user`
  ADD PRIMARY KEY (`user_id`,`permission_id`,`user_type`),
  ADD KEY `permission_user_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`,`user_type`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_student_tutoring_package_id_foreign` (`student_tutoring_package_id`),
  ADD KEY `sessions_tutoring_location_id_foreign` (`tutoring_location_id`),
  ADD KEY `sessions_tutor_id_foreign` (`tutor_id`),
  ADD KEY `sessions_monthly_invoice_package_id_foreign` (`monthly_invoice_package_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_email_unique` (`email`),
  ADD KEY `students_school_id_foreign` (`school_id`),
  ADD KEY `students_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `student_tutoring_packages`
--
ALTER TABLE `student_tutoring_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_tutoring_packages_student_id_foreign` (`student_id`),
  ADD KEY `student_tutoring_packages_tutoring_package_type_id_foreign` (`tutoring_package_type_id`),
  ADD KEY `student_tutoring_packages_tutoring_location_id_foreign` (`tutoring_location_id`);

--
-- Indexes for table `student_tutoring_package_subject`
--
ALTER TABLE `student_tutoring_package_subject`
  ADD KEY `tutoring_package_subject` (`subject_id`),
  ADD KEY `tutoring_package_id_subject` (`student_tutoring_package_id`);

--
-- Indexes for table `student_tutoring_package_tutor`
--
ALTER TABLE `student_tutoring_package_tutor`
  ADD KEY `tutoring_package_tutor` (`tutor_id`),
  ADD KEY `tutoring_package_id` (`student_tutoring_package_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxes`
--
ALTER TABLE `taxes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutoring_locations`
--
ALTER TABLE `tutoring_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutoring_package_types`
--
ALTER TABLE `tutoring_package_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tutors_email_unique` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api_calls_count`
--
ALTER TABLE `api_calls_count`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1010;

--
-- AUTO_INCREMENT for table `invoice_package_types`
--
ALTER TABLE `invoice_package_types`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `line_items`
--
ALTER TABLE `line_items`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `list_data`
--
ALTER TABLE `list_data`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `monthly_invoice_packages`
--
ALTER TABLE `monthly_invoice_packages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4008;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5007;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5016;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student_tutoring_packages`
--
ALTER TABLE `student_tutoring_packages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3005;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `taxes`
--
ALTER TABLE `taxes`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tutoring_locations`
--
ALTER TABLE `tutoring_locations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tutoring_package_types`
--
ALTER TABLE `tutoring_package_types`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tutors`
--
ALTER TABLE `tutors`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_invoice_package_type_id_foreign` FOREIGN KEY (`invoice_package_type_id`) REFERENCES `invoice_package_types` (`id`);

--
-- Constraints for table `monthly_invoice_packages`
--
ALTER TABLE `monthly_invoice_packages`
  ADD CONSTRAINT `monthly_invoice_packages_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `monthly_invoice_packages_tutoring_location_id_foreign` FOREIGN KEY (`tutoring_location_id`) REFERENCES `tutoring_locations` (`id`);

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permission_user`
--
ALTER TABLE `permission_user`
  ADD CONSTRAINT `permission_user_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_monthly_invoice_package_id_foreign` FOREIGN KEY (`monthly_invoice_package_id`) REFERENCES `monthly_invoice_packages` (`id`),
  ADD CONSTRAINT `sessions_student_tutoring_package_id_foreign` FOREIGN KEY (`student_tutoring_package_id`) REFERENCES `student_tutoring_packages` (`id`),
  ADD CONSTRAINT `sessions_tutor_id_foreign` FOREIGN KEY (`tutor_id`) REFERENCES `tutors` (`id`),
  ADD CONSTRAINT `sessions_tutoring_location_id_foreign` FOREIGN KEY (`tutoring_location_id`) REFERENCES `tutoring_locations` (`id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`),
  ADD CONSTRAINT `students_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`);

--
-- Constraints for table `student_tutoring_packages`
--
ALTER TABLE `student_tutoring_packages`
  ADD CONSTRAINT `student_tutoring_packages_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `student_tutoring_packages_tutoring_location_id_foreign` FOREIGN KEY (`tutoring_location_id`) REFERENCES `tutoring_locations` (`id`),
  ADD CONSTRAINT `student_tutoring_packages_tutoring_package_type_id_foreign` FOREIGN KEY (`tutoring_package_type_id`) REFERENCES `tutoring_package_types` (`id`);

--
-- Constraints for table `student_tutoring_package_subject`
--
ALTER TABLE `student_tutoring_package_subject`
  ADD CONSTRAINT `tutoring_package_id_subject` FOREIGN KEY (`student_tutoring_package_id`) REFERENCES `student_tutoring_packages` (`id`),
  ADD CONSTRAINT `tutoring_package_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `student_tutoring_package_tutor`
--
ALTER TABLE `student_tutoring_package_tutor`
  ADD CONSTRAINT `tutoring_package_id` FOREIGN KEY (`student_tutoring_package_id`) REFERENCES `student_tutoring_packages` (`id`),
  ADD CONSTRAINT `tutoring_package_tutor` FOREIGN KEY (`tutor_id`) REFERENCES `tutors` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
